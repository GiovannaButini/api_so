import random
from connectDB import *


ultimoResultado = "Vitória"
tentativa = 0
decisaoParticipao = "Não Participou"

inputName = input("Olá estranho! Qual é o seu nome?\n")
inputDecision = input(inputName + ", Quer participar de um sorteio e ver se você tem sorte? Se quiser, digite Y se não N.\n")

while(inputDecision != "Y" and inputDecision != "N"):
    print("Resposta inválida")
if(inputDecision == "N"):
    inputDecisionNumber = 0
    randomNumber = 0;
    ultimoResultado = "NDA"
while(inputDecision == "Y"):
    decisaoParticipao = "Participou"
    inputDecisionNumber = int(input("Escolha um número:\n"));
    randomNumber = random.randint(0, 100)
    print(f"Número sorteado: {randomNumber}")
    if inputDecisionNumber == randomNumber:
        print("Parabéns, você é muito sortudo!")
        ultimoResultado = "Vitória";
    else:
        print("Poxa, não foi dessa vez...")
        ultimoResultado = "Derrota"
    inputDecision = input(inputName + ", Você gostaria de tentar novamente? Se quiser, digite Y se não N.\n")
    tentativa = tentativa + 1
print("Tchau tchau!")

insert_db(inputName, decisaoParticipao, inputDecisionNumber, randomNumber, tentativa, ultimoResultado)
